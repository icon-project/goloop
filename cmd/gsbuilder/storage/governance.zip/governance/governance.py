from iconservice import *

TAG = 'Governance'


# An interface of token to give a reward to anyone who contributes
class SystemInterface(InterfaceScore):
    @interface
    def disableScore(self, address: Address):
        pass
    @interface
    def enableScore(self, address: Address):
        pass

    @interface
    def setRevision(self, code: int):
        pass
    @interface
    def acceptScore(self, txHash: bytes):
        pass
    @interface
    def rejectScore(self, txHash: bytes):
        pass
    @interface
    def blockScore(self, address: Address):
        pass
    @interface
    def unblockScore(self, address: Address):
        pass
    @interface
    def setStepPrice(self, price: int):
        pass
    @interface
    def setStepCost(self, type: str, cost: int):
        pass
    @interface
    def setMaxStepLimit(self, contextType: str, limit: int):
        pass
    @interface
    def addDeployer(self, address: Address):
        pass
    @interface
    def removeDeployer(self, address: Address):
        pass
    @interface
    def addMember(self, address: Address):
        pass
    @interface
    def removeMember(self, address: Address):
        pass
    @interface
    def addLicense(self, contentId: str):
        pass
    @interface
    def removeLicense(self, contentId: str):
        pass

    @interface
    def getRevision(self) -> int:
        pass
    @interface
    def getStepPrice(self) -> int:
        pass
    @interface
    def getStepCost(self, type: str) -> int:
        pass
    @interface
    def getStepCosts(self) -> str:
        pass
    @interface
    def getMaxStepLimit(self, contextType: str) -> int:
        pass
    @interface
    def getScoreStatus(self, address: Address) -> str:
        pass
    @interface
    def isDeployer(self, address: Address) -> bool:
        pass
    @interface
    def getServiceConfig(self) -> int:
        pass

class Governance(IconScoreBase):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self.system_score = self.create_interface_score(Address.from_string("cx0000000000000000000000000000000000000000"), SystemInterface)

    def on_install(self, name : str, value : int) -> None:
        print("hello : ", name, ", value : ", value)
        """
        Called when this SCORE first deployed.

        :param _fundingGoalInIcx: The funding goal of this crowdsale, in ICX
        :param _tokenScore: SCORE address of token that will be used for the rewards
        :param _durationInBlocks: the sale duration is given in number of blocks
        """
        super().on_install()


    def on_update(self) -> None:
        super().on_update()

    @payable
    def fallback(self):
        """
        Called when anyone sends funds to the SCORE.
        This SCORE regards it as a contribution.
        """
        Logger.debug(f'FundTransfer({self.msg.sender}, {amount}, True)', TAG)

    @external
    def disableScore(self, address: Address):
        self.system_score.disableScore(address)

    @external
    def enableScore(self, address: Address):
        self.system_score.enableScore(address)

    @external
    def setRevision(self, code: int):
        self.system_score.setRevision(code)

    @external
    def acceptScore(self, txHash: bytes):
        self.system_score.acceptScore(txHash)

    @external
    def rejectScore(self, txHash: bytes):
        self.system_score.rejectScore(txHash)

    @external
    def blockScore(self, address: Address):
        self.system_score.blockScore(address)

    @external
    def unblockScore(self, address: Address):
        self.system_score.unblockScore(address)

    @external
    def setStepPrice(self, stepPrice: int):
        self.system_score.setStepPrice(stepPrice)

    @external
    def setStepCost(self, stepType: str, cost: int):
        self.system_score.setStepCost(stepType, cost)

    @external
    def setMaxStepLimit(self, contextType: str, value: int):
        self.system_score.setMaxStepLimit(contextType, value)

    @external
    def addMember(self, address: Address):
        self.system_score.addMember(address)

    @external
    def removeMember(self, address: Address):
        self.system_score.removeMember(address)
    @external
    def addDeployer(self, address: Address):
        self.system_score.addDeployer(address)

    @external
    def removeDeployer(self, address: Address):
        self.system_score.removeDeployer(address)

    @external
    def addLicense(self, contentId: str):
        self.system_score.addLicense(contentId)

    @external
    def removeLicense(self, contentId: str):
        self.system_score.removeLicense(contentId)

    @external(readonly=True)
    def getRevision(self) -> int:
        return self.system_score.getRevision()

    @external(readonly=True)
    def getStepPrice(self) -> int:
        return self.system_score.getStepPrice()

    @external(readonly=True)
    def getStepCost(self, type: str) -> int:
        return self.system_score.getStepCost(type)

    @external(readonly=True)
    def getStepCosts(self) -> str:
        return self.system_score.getStepCosts()

    @external(readonly=True)
    def getMaxStepLimit(self, contextType: str) -> int:
        return self.system_score.getMaxStepLimit(contextType)

    @external(readonly=True)
    def getScoreStatus(self, address: Address) -> str:
        result = self.system_score.getScoreStatus(address)
        print("result : ", result)
        return result

    @external(readonly=True)
    def isDeployer(self, address: Address) -> bool:
        return self.system_score.isDeployer(address)

    @external(readonly=True)
    def getServiceConfig(self) -> int:
        return self.system_score.getServiceConfig()
